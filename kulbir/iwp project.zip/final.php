<?php
 echo "Your Booking is Confirmed ";
 echo "Thanks For Visiting Goods Carrier";
 ?>